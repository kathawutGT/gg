package net.openvpn.openvpn;

import android.os.Bundle;
import android.preference.PreferenceActivity;
import net.connect.chvpn.*;
import android.app.*;
import android.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
public class OpenVPNPrefs extends PreferenceActivity  {
	ActionBar action;
    public void onCreate(Bundle savedInstanceState) {
       
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.preferences);
		getActionBar().setDisplayHomeAsUpEnabled(true);
		getActionBar().setTitle("ตั้งค่า");
    }
}
