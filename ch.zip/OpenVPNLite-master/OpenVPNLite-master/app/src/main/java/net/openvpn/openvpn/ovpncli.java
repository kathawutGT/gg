package net.openvpn.openvpn;

public class ovpncli {
}
