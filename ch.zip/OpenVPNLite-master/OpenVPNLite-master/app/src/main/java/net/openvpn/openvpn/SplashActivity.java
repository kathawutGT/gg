package net.openvpn.openvpn;
import android.app.*;
import android.content.*;
import android.os.*;
import net.connect.chvpn.*;
import android.widget.*;
import android.view.animation.*;
public class SplashActivity extends Activity {
    private static boolean splashLoaded = false;
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (!splashLoaded) {
            setContentView(R.layout.splash);
			new Handler().postDelayed(new Runnable() {
					@Override
					public void run() {
						startActivity(new Intent(SplashActivity.this, OpenVPNClient.class));
						finish();
					
					}	
				}, 300);
        }
		
    }
	
	
	
}
